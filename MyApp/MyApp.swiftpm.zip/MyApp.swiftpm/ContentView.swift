import SwiftUI
///ZStack = De atras hacia enfrente
///HStack = De izquierda a derecha
///VStack = De arriba hacia abajo
struct ContentView: View {
    
    @State var animar = false
    
    var body: some View {
        ZStack {
            Color.brown.opacity(animar ? 0: 0.20)
                .animation(.linear, value: animar)
            
            VStack {
                
                Image("letra")
                    .resizable()
                    .frame(width: animar ? 100 : 100, height: 100)
                    .clipShape(RoundedRectangle(cornerRadius: 20))
                    .shadow(color: .brown, radius: 10, x: 0, y: 0)
                    .rotationEffect(Angle(degrees: animar ? 360 : 0))
                    .animation(.linear, value: animar)
                    .padding(.bottom,50)
                    .animation(.linear, value: animar)
                
                Text("Bienvenida, A D A M A R I ")
                    .font(.title)
                    .foregroundColor(.brown)
                    .bold()
                    .padding(.bottom,10)
                    .animation(.linear, value: animar)
                
                VStack(spacing: 15){
                    Text("¡Comencemos!")
                        .font(.headline)
                        .foregroundColor(.secondary)
                        .fontWeight(.semibold)
                    Text("CURSO SWIFT")
                        .font(animar ? .title : .headline)
                        .foregroundColor(.yellow)
                        .bold()
                        .shadow(color: .black, radius: 1, x: 0, y: 0)
                }
                .animation(.linear, value: animar)
                
                Button("ANIMAR"){
                    //codigo swift
                  
                    animar.toggle()
                }
                .padding()
            }
        }
        .ignoresSafeArea()
    }
}
