//
//  tarjetaView.swift
//  NewBook
//
//  Created by ADMIN UNACH on 23/03/23.
//

import SwiftUI

struct tarjetaView: View {
    
    var body: some View {
        //Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
        ZStack{
            Color.blue
                .frame(width: 350, height: 330)
                .clipShape(RoundedRectangle(cornerRadius: 20))
            
            VStack{
                Image("person")
                    .resizable()
                    .frame(width: 60, height: 60)
                    .clipShape(Circle())
                
                Text("Joaquin Ramirez")
                    .font(.largeTitle)
                    .foregroundColor(.white)
                    .bold()
                    .padding(.bottom,1)
                Text("iOS Developer")
                    .font(.headline)
                    .foregroundColor(.white)
                    .bold()
                
                HStack{
                    VStack{
                        Image(systemName: "star.fill")
                            .padding()
                            .foregroundColor(.white)
                        Text("1")
                            .foregroundColor(.white)
                    }
                    VStack{
                        Image(systemName: "heart.fill")
                        .padding()
                        .foregroundColor(.white)
                        Text("2")
                            .foregroundColor(.white)
                    }
                    VStack{
                        Image(systemName: "message.fill")
                            .padding()
                            .foregroundColor(.white)
                        Text("3")
                            .foregroundColor(.white)
                    }
                        
                    
                   
                }
                
                
                
            }
            
            
            
        }
        
        
        
    }
}

struct tarjetaView_Previews: PreviewProvider {
    static var previews: some View {
        tarjetaView()
    }
}
